package bean.controller;

public class Member {

}
