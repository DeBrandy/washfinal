package bean.controller;

public class Receive {

}
