package bean.controller;

public class Give {
public int a;
}
