package bean.controller;

public class Clothes {

}
