package bean.daoclass;

public class Operator {
   
    	private String Lname;
        private String password;
      
        public Operator(){}
    	public String getLname() {
    		return Lname;
    	}	
    	public void setLname(String lname) {
    		this.Lname = lname;
    		
    	}
    	public String getPassword() {
    		return password;
    	}
    	public void setPassword(String password) {
    		this.password = password;
    		
    	}	

}
