package bean.daoclass;

public class WashUse {
	private String uname;
	private int unum;
	public WashUse(){}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public int getUnum() {
		return unum;
	}
	public void setUnum(int unum) {
		this.unum = unum;
	}
}
