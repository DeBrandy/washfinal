package bean.daoclass;

public class WashUse {
	private String Uname;
	private int Unum;
	public WashUse(){}
	public String getUname() {
		return Uname;
	}
	public void setUname(String uname) {
		Uname = uname;
	}
	public int getUnum() {
		return Unum;
	}
	public void setUnum(int unum) {
		Unum = unum;
	}
}
