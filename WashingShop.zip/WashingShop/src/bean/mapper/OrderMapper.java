package bean.mapper;

public interface OrderMapper {

}
