package bean.mapper;

public interface WashUseMapper {

}
