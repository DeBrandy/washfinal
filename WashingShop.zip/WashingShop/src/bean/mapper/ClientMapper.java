package bean.mapper;

public interface ClientMapper {

}
